////  ANJA BUNGA ADITYA
//
////1. percabangan (IF-ELSE)
//fun main() {
//    println("Selamat datang di Aplikasi Penerjemah Bahasa Alien!")
//    println("Masukkan kalimat yang ingin Anda terjemahkan:")
//    val inputSentence = readLine()
//
//    if (inputSentence != null) {
//        val translatedSentence = translateToAlienLanguage(inputSentence)
//        println("Kalimat terjemahan: $translatedSentence")
//        configureTranslator()
//    } else {
//        println("Masukan tidak valid.")
//    }
//}
//
////2. NULLABLE TYPE
//var translatedSentence: String? = null
//
////3. ACCESSING NULLABLE TYPE (IF-ELSE UNTUK AKSES)
//fun translateToAlienLanguage(sentence: String): String {
//    val alienSentence = StringBuilder()
//    for (char in sentence) {
//        when (char.toLowerCase()) {
//            'a', 'e', 'i', 'o', 'u' -> alienSentence.append('Z')
//            else -> alienSentence.append(char)
//        }
//    }
//    return alienSentence.toString()
//}
//
////4. CLASS (1 PROPERTI, 1 FUNC)
//open class AlienTranslator(private val language: String) {
//    open fun displayLanguage() {
//        println("Bahasa yang digunakan: $language")
//    }
//}
//
////5. INHERITANCE
//class FakeAlienTranslator(language: String, private val fakeAlphabet: String) : AlienTranslator(language) {
//    //6. ENCAPSULATION
//    override fun displayLanguage() {
//        super.displayLanguage()
//        println("Alfabet palsu: $fakeAlphabet")
//    }
//}
//
//fun configureTranslator() {
//    println("Apakah Anda ingin menambahkan kode rahasia? (ya/tidak)")
//    val input = readLine()
//    if (input == "ya") {
//        println("Masukkan 3 digit angka (1-10) untuk kode rahasia:")
//        val inputCode = readLine()
//
//        if (inputCode != null && inputCode.length == 3 && inputCode.all { it.isDigit() }) {
//            val secretCode = translateSecretCode(inputCode)
//            println("Kode rahasia Anda adalah: $secretCode")
//
//            //pemanggilan displayLanguage() pada objek FakeAlienTranslator
//            val fakeTranslator = FakeAlienTranslator("Bahasa Alien", "Alfabet palsu yang dimasukkan oleh pengguna")
//            fakeTranslator.displayLanguage()
//
//            //7. PERULANGAN (FOR)
//            println("Jumlah huruf vokal dalam kalimat: ${countVowelsInSentence(secretCode)}")
//
//            //8. COLLECTION (List)
//            val secretCodeList = secretCode.toList()
//            println("Kode rahasia dalam bentuk list: $secretCodeList")
//
//            //9. SEQUENCE
//            val sequence = secretCodeList.asSequence()
//            println("Kode rahasia dalam bentuk sequence: ${sequence.toList()}")
//        } else {
//            println("Input tidak valid. Pastikan Anda memasukkan 3 digit angka (1-10).")
//        }
//    } else {
//        val translator = AlienTranslator("Bahasa Alien")
//        translator.displayLanguage()
//    }
//}
//
////10. COLLECTION (List)
//fun countVowelsInSentence(sentence: String): Int {
//    return sentence.count { it.toLowerCase() in "aeiou" }
//}
//
////11. PERULANGAN (FOR)
//fun translateSecretCode(inputCode: String): String {
//    val secretCode = StringBuilder()
//    for (char in inputCode) {
//        val digit = char.toString().toIntOrNull()
//        val letter = when (digit) {
//            1 -> "a"
//            2 -> "b"
//            3 -> "c"
//            4 -> "d"
//            5 -> "e"
//            6 -> "f"
//            7 -> "g"
//            8 -> "h"
//            9 -> "i"
//            else -> char.toString()
//        }
//        secretCode.append(letter)
//    }
//    return secretCode.toString()
//}
//
//


// ANJA BUNGA ADITYA

interface SpecialFeature {
    fun performSpecialFeature()
}

//14. DATA CLASS
data class TranslationHistory(
    val originalText: String,
    val translatedText: String,
    val translationTime: Long,
//    val additionalInfo: String
)

//1. percabangan (IF-ELSE)
fun main() {
    println("Selamat datang di Aplikasi Penerjemah Bahasa Alien!")
    println("Masukkan kalimat yang ingin Anda terjemahkan:")
    val inputSentence = readLine()

    if (inputSentence != null) {
        try {
            val translatedSentence = translateToAlienLanguage(inputSentence)
            println("Kalimat terjemahan: $translatedSentence")
            configureTranslator(inputSentence)
        } catch (e: Exception) {
            println("Terjadi kesalahan saat menerjemahkan: ${e.message}")
        }
    } else {
        println("Masukan tidak valid.")
    }
}

//2. NULLABLE TYPE
var translatedSentence: String? = null

//3. ACCESSING NULLABLE TYPE (IF-ELSE UNTUK AKSES)
fun translateToAlienLanguage(sentence: String): String {
    val alienSentence = StringBuilder()
    for (char in sentence) {
        when (char.toLowerCase()) {
            'a', 'e', 'i', 'o', 'u' -> alienSentence.append('Z')
            else -> alienSentence.append(char)
        }
    }
    return alienSentence.toString()
}

//4. CLASS (1 PROPERTI, 1 FUNC)
open class AlienTranslator(private val language: String) {
    open fun displayLanguage() {
        println("Bahasa yang digunakan: $language")
    }
}

//5. INHERITANCE
class FakeAlienTranslator(language: String, private val fakeAlphabet: String) : AlienTranslator(language), SpecialFeature {
    //6. ENCAPSULATION
    override fun displayLanguage() {
        super.displayLanguage()
        println("Alfabet palsu: $fakeAlphabet")
    }

    //7. POLYMORPHISM (overriding special feature)
    override fun performSpecialFeature() {
        println("Fitur khusus dari FakeAlienTranslator: Menampilkan alfabet palsu")
        println("Alfabet palsu: $fakeAlphabet")
    }
}

fun configureTranslator(originalText: String) {
    println("Apakah Anda ingin menambahkan kode rahasia? (ya/tidak)")
    val input = readLine()
    if (input == "ya") {
        println("Masukkan 3 digit angka (1-10) untuk kode rahasia:")
        val inputCode = readLine()

        if (inputCode != null && inputCode.length == 3 && inputCode.all { it.isDigit() }) {
            //8. TRY AND CATCH
            try {
                val secretCode = translateSecretCode(inputCode)
                println("Kode rahasia Anda adalah: $secretCode")

                // Menyimpan riwayat terjemahan ke dalam data class
                val translationHistory = TranslationHistory(
                    originalText = originalText,
                    translatedText = secretCode,
                    translationTime = System.currentTimeMillis(),
                    //additionalInfo = "Informasi Tambahan"
                )

                // Menampilkan riwayat terjemahan
                println("Riwayat Terjemahan:")
                println(translationHistory)

                //9. PERULANGAN (FOR)
                println("Jumlah huruf vokal dalam kalimat: ${countVowelsInSentence(secretCode)}")

                //10. COLLECTION (List)
                val secretCodeList = secretCode.toList()
                println("Kode rahasia dalam bentuk list: $secretCodeList")

                //11. SEQUENCE
                val sequence = secretCodeList.asSequence()
                println("Kode rahasia dalam bentuk sequence: ${sequence.toList()}")


            } catch (e: Exception) {
                println("Terjadi kesalahan saat mengonversi kode rahasia: ${e.message}")
            }
        } else {
            println("Input tidak valid. Pastikan Anda memasukkan 3 digit angka (1-10).")
        }
    } else {
        val translator = AlienTranslator("Bahasa Alien")
        translator.displayLanguage()
    }
}

//12. COLLECTION (List)
fun countVowelsInSentence(sentence: String): Int {
    return sentence.count { it.toLowerCase() in "aeiou" }
}

//13. PERULANGAN (FOR)
fun translateSecretCode(inputCode: String): String {
    val secretCode = StringBuilder()
    for (char in inputCode) {
        val digit = char.toString().toIntOrNull()
        val letter = when (digit) {
            1 -> "a"
            2 -> "b"
            3 -> "c"
            4 -> "d"
            5 -> "e"
            6 -> "f"
            7 -> "g"
            8 -> "h"
            9 -> "i"
            else -> char.toString()
        }
        secretCode.append(letter)
    }
    return secretCode.toString()
}
